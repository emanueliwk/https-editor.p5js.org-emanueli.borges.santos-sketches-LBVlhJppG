// Definindo variáveis globais
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

function setup() {
  createCanvas(700, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  // Cor de fundo varia conforme número de árvores
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1));
  background("pink");

  mostrarInformacoes();

  temperatura += 0.24;

  jardineiro.atualizar();
  jardineiro.mostra();

  // Verifica se o jogo acabou
  verificarFimDeJogo();

  // Mostrar todas as árvores
  plantas.forEach((arvore) => arvore.mostrar());
}

// Função para mostrar as informações na tela
function mostrarInformacoes() {
  textSize(26);
  fill(3);
  text("Vamos plantar árvores para reduzir a temperatura?", 20, 30);
  textSize(14);
  fill("blue")
  text("Temperatura: " + temperatura.toFixed(2), 10, 390);
  text("Árvores plantadas: " + totalArvores, 460, 390);
  text("Para movimentar o personagem use as setas do teclado.", 10, 60);
  text("Para plantar árvores use a ou espaço.", 10, 80);
}

// Função para verificar se o jogo acabou
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

// Mensagem de vitória
function mostrarMensagemDeVitoria() {
  textSize(20);
  fill(0);
  text("Você venceu! Você plantou muitas árvores!", 101, 200);
  noLoop();
}

// Mensagem de derrota
function mostrarMensagemDeDerrota() {
  textSize(20);
  fill(0);
  text("Você perdeu! A temperatura está muito alta.", 100, 200);
  noLoop();
}

// Classe Jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🎅';
    this.velocidade = 3;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.velocidade;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.velocidade;
    if (keyIsDown(UP_ARROW)) this.y -= this.velocidade;
    if (keyIsDown(DOWN_ARROW)) this.y += this.velocidade;

    // Manter dentro da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  mostra() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

// Classe Arvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    fill(34, 139, 34); // copa
    ellipse(this.x, this.y, 20, 40);
    fill(139, 69, 19); // tronco
    rect(this.x - 2, this.y, 4, 15);
  }
}

// Criar árvore com P ou espaço
function keyPressed() {
  if (key === ' ' || key === 'p' || key === 'P') {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}